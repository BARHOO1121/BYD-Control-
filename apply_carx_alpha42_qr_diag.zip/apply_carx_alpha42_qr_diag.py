from pathlib import Path

root = Path('/workspaces/BYD-Control-')
api_path = root/'app/src/main/java/com/carx/byd/BydApiClient.java'
qr_path = root/'app/src/main/java/com/carx/byd/QrPayload.java'
gradle_path = root/'app/build.gradle'

for p in (api_path, qr_path, gradle_path):
    if not p.exists():
        raise SystemExit(f'❌ Missing: {p}')

qr_new = r'''package com.carx.byd;

import android.net.Uri;
import org.json.JSONObject;

public final class QrPayload {
    public final String raw, scanId, scanIdent, innerToken, vkey256, tokenTime, vin, scanVinProvider;

    private QrPayload(String raw,String scanId,String scanIdent,String innerToken,String vkey256,String tokenTime,String vin,String scanVinProvider){
        this.raw=raw;
        this.scanId=scanId;
        this.scanIdent=scanIdent;
        this.innerToken=innerToken;
        this.vkey256=vkey256;
        this.tokenTime=tokenTime;
        this.vin=vin;
        this.scanVinProvider=scanVinProvider;
    }

    public static QrPayload parse(String raw){
        String s=raw==null?"":raw.trim();
        String scanId="",scanIdent="",token="",vkey="",tokenTime="",vin="",vinProvider="";
        try{
            if(s.startsWith("{") && s.endsWith("}")){
                JSONObject o=new JSONObject(s);
                scanId=first(o,"scanId","scan_id","id");
                scanIdent=first(o,"scanIdent","scan_ident","ident");
                token=first(o,"scanInnerToken","innerToken","token");
                vkey=first(o,"vkey256","vKey256","vkey","vKey");
                tokenTime=first(o,"tokenTime","token_time","timeStamp","timestamp");
                vin=first(o,"vin","carVin","vehicleVin","scanVin");
                vinProvider=first(o,"scanVinProvider","vinProvider");
            }
        }catch(Exception ignored){}
        try{
            Uri u=Uri.parse(s);
            if(scanId.isEmpty()) scanId=param(u,"scan_id","scanId","id");
            if(scanIdent.isEmpty()) scanIdent=param(u,"scanIdent","scan_ident","ident");
            if(token.isEmpty()) token=param(u,"scanInnerToken","innerToken","token");
            if(vkey.isEmpty()) vkey=param(u,"vkey256","vKey256","vkey","vKey");
            if(tokenTime.isEmpty()) tokenTime=param(u,"tokenTime","token_time","timeStamp","timestamp");
            if(vin.isEmpty()) vin=param(u,"vin","carVin","vehicleVin","scanVin");
            if(vinProvider.isEmpty()) vinProvider=param(u,"scanVinProvider","vinProvider");
        }catch(Exception ignored){}
        return new QrPayload(s,scanId,scanIdent,token,vkey,tokenTime,vin,vinProvider);
    }

    public String safeShape(){
        return "scanId="+yn(scanId)+
                ", scanIdent="+yn(scanIdent)+
                ", innerToken="+yn(innerToken)+
                ", vkey="+yn(vkey256)+
                ", tokenTime="+yn(tokenTime)+
                ", vin="+yn(vin)+
                ", vinProvider="+yn(scanVinProvider)+
                ", rawLen="+raw.length();
    }

    private static String yn(String s){return s==null||s.isEmpty()?"no":"yes";}
    private static String param(Uri u,String...keys){for(String k:keys){String v=u.getQueryParameter(k);if(v!=null&&!v.isEmpty())return v;}return"";}
    private static String first(JSONObject o,String...keys){for(String k:keys){String v=o.optString(k,"");if(!v.isEmpty())return v;}return"";}
}
'''
qr_path.write_text(qr_new, encoding='utf-8')

api = api_path.read_text(encoding='utf-8')
old_auth = '''        Object decoded=postTokenJson("/user/scanlogin/scanLoginByAuth",inner,null);\n        return asJsonObject(decoded);'''
new_auth = '''        try {\n            Object decoded=postTokenJson("/user/scanlogin/scanLoginByAuth",inner,null);\n            return asJsonObject(decoded);\n        } catch (BydException e) {\n            throw new BydException(e.getMessage()+"\\nQR shape: "+q.safeShape());\n        }'''
if old_auth not in api:
    raise SystemExit('❌ scanLoginByAuth pattern not found; stopped')
api = api.replace(old_auth, new_auth, 1)

old_resp = '''        JSONObject response=postSecure(endpoint,o);String code=response.optString("code","");if(!"0".equals(code)){if(allowReauth&&("1002".equals(code)||"1005".equals(code)||"1010".equals(code))){session=null;login();return postTokenJson(endpoint,inner,vin,false);}throw new BydException("BYD "+code+": "+response.optString("message","API error"));}\n        String rd=response.optString("respondData","");'''
new_resp = '''        JSONObject response=postSecure(endpoint,o);\n        String code=response.optString("code","");\n        boolean qrEndpoint=endpoint.contains("/scanlogin/")||endpoint.contains("/scanLoginWatch/");\n        if(code.isEmpty() && qrEndpoint && response.has("respondData") && !response.optString("respondData","").isEmpty()) code="0";\n        if(!"0".equals(code)){\n            if(allowReauth&&("1002".equals(code)||"1005".equals(code)||"1010".equals(code))){session=null;login();return postTokenJson(endpoint,inner,vin,false);}\n            if(qrEndpoint) throw new BydException("BYD QR: "+safeResponseSummary(response));\n            throw new BydException("BYD "+code+": "+response.optString("message",response.optString("msg","API error")));\n        }\n        String rd=response.optString("respondData","");'''
if old_resp not in api:
    raise SystemExit('❌ postTokenJson response pattern not found; stopped')
api = api.replace(old_resp, new_resp, 1)

anchor = '''    private static String randomHex(int n){byte[] b=new byte[n];RNG.nextBytes(b);return BydCrypto.bytesToHex(b,true);}\n'''
helper = '''    private static String safeResponseSummary(JSONObject r){\n        StringBuilder b=new StringBuilder();\n        String[] keys={"code","message","msg","retCode","resultCode","status","success","errorCode","errorMsg"};\n        for(String k:keys){\n            if(!r.has(k)||r.isNull(k))continue;\n            Object v=r.opt(k);\n            if(v instanceof JSONObject||v instanceof JSONArray)continue;\n            String s=String.valueOf(v);\n            if(s.length()>160)s=s.substring(0,160);\n            if(b.length()>0)b.append(" | ");\n            b.append(k).append("=").append(s);\n        }\n        JSONArray names=r.names();\n        if(names!=null){if(b.length()>0)b.append(" | ");b.append("fields=").append(names.toString());}\n        if(r.has("respondData")){if(b.length()>0)b.append(" | ");b.append("respondData=").append(r.optString("respondData","").isEmpty()?"empty":"present");}\n        if(b.length()==0)b.append("empty response metadata");\n        return trim(b.toString(),900);\n    }\n\n'''
if anchor not in api:
    raise SystemExit('❌ helper anchor not found; stopped')
api = api.replace(anchor, helper + anchor, 1)
api_path.write_text(api, encoding='utf-8')

gradle = gradle_path.read_text(encoding='utf-8')
gradle = gradle.replace("versionCode 4", "versionCode 5")
gradle = gradle.replace("versionName '1.0.0-alpha4'", "versionName '1.0.0-alpha4.2-qrdiag'")
gradle = gradle.replace("versionName '1.0.0-alpha4.1'", "versionName '1.0.0-alpha4.2-qrdiag'")
gradle_path.write_text(gradle, encoding='utf-8')

print('✅ Car X BYD Alpha 4.2 QR diagnostic patch applied')
print('✅ No QR/token values will be shown; only field presence and BYD response metadata')
